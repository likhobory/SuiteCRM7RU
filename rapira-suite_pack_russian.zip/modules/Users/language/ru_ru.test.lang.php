$mod_strings = array(
 
    'LNK_LIST_CALENDAR_ACCOUNTS' => 'Учётные записи календаря',

); // END STRINGS DEFS

