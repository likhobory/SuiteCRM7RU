<?php

$mod_strings['LBL_SECURITYGROUPS'] = 'Фильтр по группам пользователей';
?>