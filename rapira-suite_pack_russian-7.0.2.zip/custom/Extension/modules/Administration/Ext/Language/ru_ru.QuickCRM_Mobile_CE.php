<?php

$mod_strings['LBL_UPDATE_QUICKCRM_TITLE'] = "Настройка QuickCRM"; 
$mod_strings['LBL_UPDATE_QUICKCRM'] = "Настройка приложения для работы через мобильные устройства";
$mod_strings['LBL_QUICKCRM'] = 'QuickCRM Mobile';
$mod_strings['LBL_CONFIG_QUICKCRM_TITLE'] = "Configuration of QuickCRM Mobile";
$mod_strings['LBL_CONFIG_QUICKCRM'] = "Definition of visible modules and fields";
$mod_strings['LBL_UPDATE_MSG'] = '<strong>Приложение настроено для работы через мобильные устройства.</strong><br/> Мобильная версия доступна по ссылке:';
$mod_strings['LBL_ERR_DIR_MSG'] = 'Некоторые файлы не могут быть созданы. Проверьте права доступа для: ';  


