<?php
$mod_strings['LBL_SALESAGILITY_ADMIN'] = 'OpenAdmin';
$mod_strings['LBL_AOS_ADMIN_CONTRACT_SETTINGS'] = 'Параметры договоров';
$mod_strings['LBL_AOS_ADMIN_CONTRACT_RENEWAL_REMINDER'] = 'Период действия договора';
$mod_strings['LBL_AOS_ADMIN_MANAGE_AOS'] = 'Параметры модулей продаж';
$mod_strings['LBL_AOS_ADMIN_INVOICE_SETTINGS'] = 'Параметры счетов';
$mod_strings['LBL_AOS_ADMIN_INITIAL_INVOICE_NUMBER'] = 'Начинать нумерацию с';
$mod_strings['LBL_AOS_ADMIN_QUOTE_SETTINGS'] = 'Параметры предложений';
$mod_strings['LBL_AOS_ADMIN_INITIAL_QUOTE_NUMBER'] = 'Начинать нумерацию с';
$mod_strings['LBL_AOS_ADMIN_LINE_ITEM_SETTINGS'] = 'Настройка позиций в бланках';
$mod_strings['LBL_AOS_ADMIN_ENABLE_LINE_ITEM_GROUPS'] = 'Возможность группировки позиций';
$mod_strings['LBL_AOS_ADMIN_ENABLE_LINE_ITEM_TOTAL_TAX'] = 'Включать НДС в сумму<br>(для каждой позиции)';

