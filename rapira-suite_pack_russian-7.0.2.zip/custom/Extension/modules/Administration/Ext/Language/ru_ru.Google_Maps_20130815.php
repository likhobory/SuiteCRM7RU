<?php

$mod_strings['LBL_JJWG_MAPS_ADMIN_HEADER'] = 'Карты Google';
$mod_strings['LBL_JJWG_MAPS_ADMIN_DESC'] = 'Управление геокодированием, тестирование геокодирования, просмотр результатов геокодирования, настройка параметров карт';
$mod_strings['LBL_JJWG_MAPS_ADMIN_CONFIG_TITLE'] = 'Настройка карт Google';
$mod_strings['LBL_JJWG_MAPS_ADMIN_CONFIG_DESC'] = 'Настройка параметров карт Google';
$mod_strings['LBL_JJWG_MAPS_ADMIN_GEOCODED_COUNTS_TITLE'] = 'Результаты геокодирования';
$mod_strings['LBL_JJWG_MAPS_ADMIN_GEOCODED_COUNTS_DESC'] = 'Просмотр статистики геокодирования, данные по каждому модулю сгруппированы в зависимости от полученных результатов';
$mod_strings['LBL_JJWG_MAPS_ADMIN_DONATE_TITLE'] = 'Поддержка проекта';
$mod_strings['LBL_JJWG_MAPS_ADMIN_DONATE_DESC'] = ' ';
$mod_strings['LBL_JJWG_MAPS_ADMIN_GEOCODE_ADDRESSES_TITLE'] = 'Геокодирование адресов';
$mod_strings['LBL_JJWG_MAPS_ADMIN_GEOCODE_ADDRESSES_DESC'] = 'Геокодирование адресов системы, этот процесс может занять продолжительное время!';
$mod_strings['LBL_JJWG_MAPS_ADMIN_GEOCODING_TEST_TITLE'] = 'Тестирование геокодирования';
$mod_strings['LBL_JJWG_MAPS_ADMIN_GEOCODING_TEST_DESC'] = 'Запуск геокодирования введённого адреса с детальным просмотром результатов';
$mod_strings['LBL_JJWG_MAPS_ADMIN_ADDRESS_CACHE_TITLE'] = 'Кэш адресов';
$mod_strings['LBL_JJWG_MAPS_ADMIN_ADDRESS_CACHE_DESC'] = 'Доступ к кэшу адресов. Обратите внимание: это только кэш!';
