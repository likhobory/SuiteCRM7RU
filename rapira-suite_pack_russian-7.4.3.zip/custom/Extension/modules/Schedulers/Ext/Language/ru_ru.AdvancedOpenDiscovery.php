<?php
$mod_strings['LBL_AODOPTIMISEINDEX'] = 'Оптимизировать индекс полнотекстового поиска'; 
$mod_strings['LBL_AODINDEXUNINDEXED'] = 'Индексировать неиндексированные документы'; 
