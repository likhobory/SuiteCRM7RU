<?php
/**
 * en_us.sps.php
 * @author SalesAgility <support@salesagility.com>
 * Date: 27/01/14
 */


$app_strings['LBL_SUBPANEL_FILTER_LABEL'] = 'Фильтр';