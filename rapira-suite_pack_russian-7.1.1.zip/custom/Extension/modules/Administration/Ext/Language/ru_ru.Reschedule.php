<?php
    
$mod_strings['LBL_RESCHEDULE_REBUILD'] = 'Восстановить отложенные звонки';
$mod_strings['LBL_RESCHEDULE_REBUILD_DESC'] = 'Восстановление модуля отложенных звонков';
$mod_strings['LBL_RESCHEDULE_ADMIN'] = 'Отложенные звонки';
$mod_strings['LBL_RESCHEDULE_ADMIN_DESC'] = 'Настройка отложенных звонков';
$mod_strings['LBL_REPAIR_RESCHEDULE_DONE'] = 'Отложенные звонки успешно восстановлены';
$mod_strings['LBL_SALESAGILITY_ADMIN'] = 'OpenAdmin';

