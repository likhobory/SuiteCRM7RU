<?php 
 //WARNING: The contents of this file are auto-generated


//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_FP_EVENTS_CONTACTS_FROM_CONTACTS_TITLE'] = 'Контакты';
//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_FP_EVENTS_FP_EVENT_LOCATIONS_1_FROM_FP_EVENT_LOCATIONS_TITLE'] = 'Место проведения события';
$mod_strings['LBL_FP_EVENT_LOCATIONS_FP_EVENTS_1_FROM_FP_EVENT_LOCATIONS_TITLE'] = 'Место проведения события';
$mod_strings['LBL_FP_EVENTS_LEADS_1_FROM_LEADS_TITLE'] = 'Предварит. контакты';
$mod_strings['LBL_FP_EVENTS_PROSPECTS_1_FROM_PROSPECTS_TITLE'] = 'Адресаты';
$mod_strings['LBL_FP_EVENTS_FP_EVENT_DELEGATES_1_FROM_FP_EVENT_DELEGATES_TITLE'] = 'Участники';
$mod_strings['LBL_FP_EVENTS_CONTACTS_FROM_CONTACTS_TITLE'] = 'Контакты';

?>