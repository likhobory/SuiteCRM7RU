<?php 
 //WARNING: The contents of this file are auto-generated


//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_FP_EVENTS_PROSPECTS_1_FROM_FP_EVENTS_TITLE'] = 'События';

?>
