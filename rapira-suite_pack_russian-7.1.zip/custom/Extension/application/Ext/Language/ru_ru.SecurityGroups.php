<?php

$app_list_strings["moduleList"]["SecurityGroups"] = 'Группы пользователей';
$app_strings['LBL_LOGIN_AS'] = "Login as ";
$app_strings['LBL_LOGOUT_AS'] = "Logout as ";

?>