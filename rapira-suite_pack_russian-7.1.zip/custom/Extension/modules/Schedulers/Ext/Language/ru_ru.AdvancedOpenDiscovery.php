<?php
$mod_strings['LBL_AODOPTIMISEINDEX'] = 'Оптимизация индекса полнотекстового поиска'; ///
$mod_strings['LBL_AODINDEXUNINDEXED'] = 'Неиндексированные документы'; ///
